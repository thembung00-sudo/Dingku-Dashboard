# DINGKU Dashboard (Android app)
Offline dashboard for Excel (.xlsx), CSV and text-based PDF files. App code: app/src/main/assets/index.html
Build: GitHub Actions (see workflow in chat) or Android Studio > Build APK.
